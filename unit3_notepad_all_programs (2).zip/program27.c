// Variable Sized Arrays
#include <stdio.h>
#include <stdlib.h>
int main() {
    int n, q;
    scanf("%d %d", &n, &q);
    int **a = malloc(n * sizeof(int *));
    for (int i = 0; i < n; i++) {
        int k;
        scanf("%d", &k);
        a[i] = malloc(k * sizeof(int));
        for (int j = 0; j < k; j++) scanf("%d", &a[i][j]);
    }
    while (q--) {
        int i, j;
        scanf("%d %d", &i, &j);
        printf("%d\n", a[i][j]);
    }
    for (int i = 0; i < n; i++) free(a[i]);
    free(a);
    return 0;
}

// 2D Array - DS (maximum hourglass sum)
#include <stdio.h>
int main() {
    int a[6][6], best = -1000;
    for (int i = 0; i < 6; i++)
        for (int j = 0; j < 6; j++) scanf("%d", &a[i][j]);
    for (int i = 0; i < 4; i++)
        for (int j = 0; j < 4; j++) {
            int s = a[i][j] + a[i][j+1] + a[i][j+2]
                  + a[i+1][j+1]
                  + a[i+2][j] + a[i+2][j+1] + a[i+2][j+2];
            if (s > best) best = s;
        }
    printf("%d\n", best);
    return 0;
}

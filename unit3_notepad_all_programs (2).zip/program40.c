// Between Two Sets (LCM of array A, GCD of array B)
#include <stdio.h>

int gcd(int a, int b) { return b == 0 ? a : gcd(b, a % b); }
int lcm(int a, int b) { return a / gcd(a, b) * b; }

int main() {
    int n, m, a[10], b[10];
    scanf("%d %d", &n, &m);
    for (int i = 0; i < n; i++) scanf("%d", &a[i]);
    for (int i = 0; i < m; i++) scanf("%d", &b[i]);
    int L = a[0], G = b[0];
    for (int i = 1; i < n; i++) L = lcm(L, a[i]);
    for (int i = 1; i < m; i++) G = gcd(G, b[i]);
    int count = 0;
    for (int x = L; x <= G; x += L)
        if (G % x == 0) count++;
    printf("%d\n", count);
    return 0;
}

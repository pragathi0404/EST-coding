// Super Reduced String
#include <stdio.h>
#include <string.h>
int main() {
    char s[1005], st[1005];
    int top = 0;
    scanf("%s", s);
    for (int i = 0; s[i]; i++) {
        if (top > 0 && st[top - 1] == s[i]) top--;
        else st[top++] = s[i];
    }
    st[top] = '\0';
    if (top == 0) printf("Empty String\n");
    else printf("%s\n", st);
    return 0;
}

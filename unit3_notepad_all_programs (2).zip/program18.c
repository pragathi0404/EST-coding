// Funny String
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
int main() {
    int t;
    char s[10005];
    scanf("%d", &t);
    while (t--) {
        scanf("%s", s);
        int n = strlen(s), funny = 1;
        for (int i = 1; i < n; i++) {
            int d1 = abs(s[i] - s[i - 1]);
            int d2 = abs(s[n - 1 - i] - s[n - i]);
            if (d1 != d2) { funny = 0; break; }
        }
        printf(funny ? "Funny\n" : "Not Funny\n");
    }
    return 0;
}

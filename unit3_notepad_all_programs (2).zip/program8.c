// Conditional Statements
#include <stdio.h>
int main() {
    const char *w[] = {"", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine"};
    int n;
    scanf("%d", &n);
    if (n >= 1 && n <= 9) printf("%s\n", w[n]);
    else if (n > 9) printf("Greater than 9\n");
    return 0;
}

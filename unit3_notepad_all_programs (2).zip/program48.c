// Pascal's Triangle: print the first n rows
#include <stdio.h>

int main() {
    int n;
    scanf("%d", &n);
    for (int i = 0; i < n; i++) {
        long long c = 1;
        for (int j = 0; j <= i; j++) {
            printf("%lld ", c);
            c = c * (i - j) / (j + 1);
        }
        printf("\n");
    }
    return 0;
}

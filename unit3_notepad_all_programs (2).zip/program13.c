// Plus Minus
#include <stdio.h>
int main() {
    int n, x, pos = 0, neg = 0, zero = 0;
    scanf("%d", &n);
    for (int i = 0; i < n; i++) {
        scanf("%d", &x);
        if (x > 0) pos++;
        else if (x < 0) neg++;
        else zero++;
    }
    printf("%.6f\n%.6f\n%.6f\n", (double)pos / n, (double)neg / n, (double)zero / n);
    return 0;
}

// CamelCase (number of words in a camelCase string)
#include <stdio.h>
#include <ctype.h>
int main() {
    char s[100005];
    scanf("%s", s);
    int words = 1;
    for (int i = 0; s[i]; i++)
        if (isupper((unsigned char)s[i])) words++;
    printf("%d\n", words);
    return 0;
}

// Recursion: Davis' Staircase (steps of 1, 2 or 3)
#include <stdio.h>
#define MOD 10000000007LL

long long memo[40];

long long ways(int n) {
    if (n < 0) return 0;
    if (n == 0) return 1;
    if (memo[n]) return memo[n];
    return memo[n] = (ways(n - 1) + ways(n - 2) + ways(n - 3)) % MOD;
}

int main() {
    int s, n;
    scanf("%d", &s);
    while (s--) {
        scanf("%d", &n);
        printf("%lld\n", ways(n));
    }
    return 0;
}

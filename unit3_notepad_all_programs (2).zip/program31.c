// Deque-STL (maximum of every subarray of size k) - deque implemented with an array
#include <stdio.h>
#include <stdlib.h>
int main() {
    int t;
    scanf("%d", &t);
    while (t--) {
        int n, k;
        scanf("%d %d", &n, &k);
        int *a = malloc(n * sizeof(int));
        int *dq = malloc(n * sizeof(int));   // stores indices
        int head = 0, tail = 0;              // dq[head..tail-1]
        for (int i = 0; i < n; i++) scanf("%d", &a[i]);
        for (int i = 0; i < n; i++) {
            if (head < tail && dq[head] <= i - k) head++;           // out of window
            while (head < tail && a[dq[tail - 1]] <= a[i]) tail--;   // smaller values useless
            dq[tail++] = i;
            if (i >= k - 1) printf("%d ", a[dq[head]]);
        }
        printf("\n");
        free(a);
        free(dq);
    }
    return 0;
}

// The Power Sum
#include <stdio.h>

int ipow(int base, int exp) {
    int r = 1;
    for (int i = 0; i < exp; i++) r *= base;
    return r;
}

int ways(int x, int n, int num) {
    int p = ipow(num, n);
    if (p > x) return 0;
    if (p == x) return 1;
    return ways(x - p, n, num + 1) + ways(x, n, num + 1);
}

int main() {
    int x, n;
    scanf("%d %d", &x, &n);
    printf("%d\n", ways(x, n, 1));
    return 0;
}

// Fraudulent Activity Notifications (bucket counting, expenditures are 0..200)
#include <stdio.h>
#include <stdlib.h>

// k-th smallest (1-based) among the values currently in the window
int kth(int *count, int k) {
    int run = 0;
    for (int v = 0; v <= 200; v++) {
        run += count[v];
        if (run >= k) return v;
    }
    return 0;
}

int main() {
    int n, d;
    scanf("%d %d", &n, &d);
    int *a = malloc(n * sizeof(int));
    for (int i = 0; i < n; i++) scanf("%d", &a[i]);
    int count[201] = {0}, notices = 0;
    for (int i = 0; i < d && i < n; i++) count[a[i]]++;
    for (int i = d; i < n; i++) {
        int twice;                                   // 2 * median
        if (d % 2) twice = 2 * kth(count, d / 2 + 1);
        else twice = kth(count, d / 2) + kth(count, d / 2 + 1);
        if (a[i] >= twice) notices++;
        count[a[i - d]]--;
        count[a[i]]++;
    }
    printf("%d\n", notices);
    free(a);
    return 0;
}

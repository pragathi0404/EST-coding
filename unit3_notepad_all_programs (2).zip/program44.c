// Power of Large Numbers: a^b mod (1e9+7), where a and b are given as big decimal strings
#include <stdio.h>
#include <string.h>
#define MOD 1000000007ULL

static char A[1000005], B[1000005];

unsigned long long str_mod(const char *s, unsigned long long m) {
    unsigned long long r = 0;
    for (int i = 0; s[i]; i++) r = (r * 10 + (s[i] - '0')) % m;
    return r;
}

unsigned long long power(unsigned long long base, unsigned long long exp) {
    unsigned long long r = 1;
    base %= MOD;
    while (exp > 0) {
        if (exp & 1) r = r * base % MOD;
        base = base * base % MOD;
        exp >>= 1;
    }
    return r;
}

int main() {
    int t;
    scanf("%d", &t);
    while (t--) {
        scanf("%s %s", A, B);
        unsigned long long a = str_mod(A, MOD);
        unsigned long long e = str_mod(B, MOD - 1);   // Fermat's little theorem
        if (a == 0) printf("0\n");
        else printf("%llu\n", power(a, e));
    }
    return 0;
}

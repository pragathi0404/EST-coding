// Project Euler #10: Summation of primes (sieve + prefix sums)
#include <stdio.h>
#define LIMIT 1000000

static char composite[LIMIT + 1];
static long long prefix[LIMIT + 1];

int main() {
    for (int i = 2; i <= LIMIT; i++) {
        if (!composite[i])
            for (long long j = (long long)i * i; j <= LIMIT; j += i) composite[j] = 1;
    }
    for (int i = 1; i <= LIMIT; i++)
        prefix[i] = prefix[i - 1] + ((i >= 2 && !composite[i]) ? i : 0);
    int t, n;
    scanf("%d", &t);
    while (t--) {
        scanf("%d", &n);
        printf("%lld\n", prefix[n]);
    }
    return 0;
}

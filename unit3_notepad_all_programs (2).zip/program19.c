// Pangrams
#include <stdio.h>
#include <ctype.h>
int main() {
    char s[1005];
    int seen[26] = {0}, count = 0;
    fgets(s, sizeof(s), stdin);
    for (int i = 0; s[i]; i++) {
        if (isalpha((unsigned char)s[i])) {
            int k = tolower((unsigned char)s[i]) - 'a';
            if (!seen[k]) { seen[k] = 1; count++; }
        }
    }
    printf(count == 26 ? "pangram\n" : "not pangram\n");
    return 0;
}

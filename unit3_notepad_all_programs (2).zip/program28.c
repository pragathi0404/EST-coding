// Sherlock and Array (prefix sums)
#include <stdio.h>
#include <stdlib.h>
int main() {
    int t;
    scanf("%d", &t);
    while (t--) {
        int n;
        scanf("%d", &n);
        int *a = malloc(n * sizeof(int));
        long long total = 0, left = 0;
        for (int i = 0; i < n; i++) { scanf("%d", &a[i]); total += a[i]; }
        int found = 0;
        for (int i = 0; i < n; i++) {
            if (left == total - left - a[i]) { found = 1; break; }
            left += a[i];
        }
        printf(found ? "YES\n" : "NO\n");
        free(a);
    }
    return 0;
}

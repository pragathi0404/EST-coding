// Time Complexity: Primality (also covers Day 25: Running Time and Complexity)
#include <stdio.h>

int main() {
    int p;
    scanf("%d", &p);
    while (p--) {
        long long n;
        scanf("%lld", &n);
        int prime = (n >= 2);
        for (long long i = 2; i * i <= n; i++) {
            if (n % i == 0) { prime = 0; break; }
        }
        printf(prime ? "Prime\n" : "Not prime\n");
    }
    return 0;
}

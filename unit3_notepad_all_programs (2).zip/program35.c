// Recursive Digit Sum (super digit)
#include <stdio.h>
#include <string.h>

long long super_digit(long long x) {
    if (x < 10) return x;
    long long s = 0;
    while (x > 0) { s += x % 10; x /= 10; }
    return super_digit(s);
}

int main() {
    static char n[100005];
    long long k, s = 0;
    scanf("%s %lld", n, &k);
    for (int i = 0; n[i]; i++) s += n[i] - '0';
    printf("%lld\n", super_digit(s * k));
    return 0;
}

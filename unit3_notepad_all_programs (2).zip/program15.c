// Diagonal Difference
#include <stdio.h>
#include <stdlib.h>
int main() {
    int n, x, d1 = 0, d2 = 0;
    scanf("%d", &n);
    for (int i = 0; i < n; i++)
        for (int j = 0; j < n; j++) {
            scanf("%d", &x);
            if (i == j) d1 += x;
            if (i + j == n - 1) d2 += x;
        }
    printf("%d\n", abs(d1 - d2));
    return 0;
}
